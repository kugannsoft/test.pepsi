<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="content-wrapper">
    <section class="content">
        <h1>No Access For The This User</h1>  
        <p style="font-size: 200px; text-align: center">500</p>
    </section>
    
</div>