<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="content-wrapper">
    <section class="content-header">
        <span style="font-size: 25px;"><?php echo $pagetitle; ?></span>
    </section>
    <section class="content">
    	 
    </section>
</div>